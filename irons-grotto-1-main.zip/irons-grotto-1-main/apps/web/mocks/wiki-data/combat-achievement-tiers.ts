export const combatAchievementTierFixture = {
  expandtemplates: {
    wikitext: '35|139|373|989|1779|2445',
  },
};
