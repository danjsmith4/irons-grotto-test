export type RedisPipelineJsonGetResponse = { result: string | null }[];
