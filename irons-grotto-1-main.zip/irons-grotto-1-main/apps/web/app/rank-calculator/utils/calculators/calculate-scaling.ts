export function calculateScaling(_joinDate: Date | null) {
  return 1;
}
