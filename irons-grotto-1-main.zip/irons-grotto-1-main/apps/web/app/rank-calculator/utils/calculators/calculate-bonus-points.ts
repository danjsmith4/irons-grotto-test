export function calculateBonusPoints(points: number, multiplier: number) {
  return points * multiplier;
}
