export function usePageHeight() {
  return `calc(100vh - 62px)`;
}
