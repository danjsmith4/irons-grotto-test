export class ActionError extends Error {}
